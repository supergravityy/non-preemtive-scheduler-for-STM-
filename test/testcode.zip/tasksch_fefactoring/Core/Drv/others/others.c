
#include "others.h"
#include "main.h"
#include <stdbool.h>
#include <string.h>
#include <stdio.h>

#define POMETER_BUFFER_SIZE     (5U)
#define POMETER_DEVIDE_SIZE     ((float)POMETER_BUFFER_SIZE)

#define UART_BUFFER_SIZE		(30U)
#define UART_HEARTBEAT_STR		"HB_SIG"
#define UART_HEARTBEAT_OR		"OR :"

static uint16_t poMeter_rawVal_arr[POMETER_BUFFER_SIZE];
static float poMeter_avgVolt;
static uint16_t dummyNum = 1000;
static char uart_normal_bufferTx[UART_BUFFER_SIZE];
static char uart_event_bufferTx[UART_BUFFER_SIZE];
static uint16_t uart_HB_num;

void poMeter_updateVoltage(void)
{
    float poMeter_avgRawVal = 0;
    uint32_t sum = 0;

	for (int i = 0; i < POMETER_BUFFER_SIZE; i++)
		sum += poMeter_rawVal_arr[i];

	poMeter_avgRawVal = ((float) sum) / POMETER_DEVIDE_SIZE;

	poMeter_avgVolt = (3.3f * poMeter_avgRawVal) / 4095.0f;

	HAL_ADC_Start_DMA(POMETER_HANDLER, (uint32_t*) poMeter_rawVal_arr,
			POMETER_BUFFER_SIZE);

}
float poMeter_getVoltage(void)
{
    return poMeter_avgVolt;
}

void boardLED_setOn(void)
{
    HAL_GPIO_WritePin(LED_OUTPUT_GPIO_Port, LED_OUTPUT_Pin, 0);
}

void boardLED_toggleStat(void)
{
    HAL_GPIO_TogglePin(LED_OUTPUT_GPIO_Port, LED_OUTPUT_Pin);
}

void dummy_calculation(void)
{
    volatile uint32_t dummy = 0;
    for(int i=0; i<dummyNum; i++) 
    {
        dummy++;
    }
}

static void uart_send_DMA(const char* str)
{
    if (HAL_UART_GetState(UART_HANDLER) == HAL_UART_STATE_READY)
    {
        uint16_t len = strlen(str);
        if (len > 0)
        {
            // 실제 DMA 전송 시작 (huart1 사용 가정)
            HAL_UART_Transmit_DMA(UART_HANDLER, (uint8_t*)str, len);
        }
    }
}

void uart_HeartBeat_sig(uint16_t overRunCnt)
{
	memset((void*) uart_normal_bufferTx, 0,UART_BUFFER_SIZE);

	snprintf(uart_normal_bufferTx,sizeof(uart_normal_bufferTx),"%s %d, %s %d\r\n"
			,UART_HEARTBEAT_STR,++uart_HB_num,UART_HEARTBEAT_OR,overRunCnt);

	if(uart_HB_num >= 100)
		uart_HB_num = 0;

    uart_send_DMA(uart_normal_bufferTx);
}

void uart_send_staticStr(const char* str) // \r\n 꼭 붙이기
{
	memset((void*)uart_normal_bufferTx, 0, UART_BUFFER_SIZE);
    strncpy(uart_normal_bufferTx, str, UART_BUFFER_SIZE - 1);
    uart_send_DMA(uart_normal_bufferTx);
}

void uart_send_beforeOFF(const char* str)
{
	HAL_UART_AbortTransmit(UART_HANDLER);

	memset((void*) uart_event_bufferTx, 0, UART_BUFFER_SIZE);
	HAL_UART_Transmit(UART_HANDLER,(const uint8_t*)"\r\n",2,10);
	strncpy(uart_event_bufferTx, str, UART_BUFFER_SIZE - 1);
	HAL_UART_Transmit(UART_HANDLER,(const uint8_t*)uart_event_bufferTx,UART_BUFFER_SIZE,500);
}

/*---- GPIO MEASURING ----*/

void meaure_task_pinSet_1ms(void)
{
    HAL_GPIO_WritePin(TASK_1MS_MEASURING_GPIO_Port,TASK_1MS_MEASURING_Pin,1);
}
void meaure_task_pinSet_5ms(void)
{
    HAL_GPIO_WritePin(TASK_5MS_MEASURING_GPIO_Port,TASK_5MS_MEASURING_Pin,1);
}
void meaure_task_pinSet_10ms(void)
{
    HAL_GPIO_WritePin(TASK_10MS_MEASURING_GPIO_Port,TASK_10MS_MEASURING_Pin,1);
}
void meaure_task_pinSet_100ms(void)
{
    HAL_GPIO_WritePin(TASK_100MS_MEASURING_GPIO_Port,TASK_100MS_MEASURING_Pin,1);
}
void meaure_task_pinSet_500ms(void)
{
    HAL_GPIO_WritePin(TASK_500MS_MEASURING_GPIO_Port,TASK_500MS_MEASURING_Pin,1);
}
void meaure_task_pinClr_1ms(void)
{
    HAL_GPIO_WritePin(TASK_1MS_MEASURING_GPIO_Port,TASK_1MS_MEASURING_Pin,0);
}
void meaure_task_pinClr_5ms(void)
{
    HAL_GPIO_WritePin(TASK_5MS_MEASURING_GPIO_Port,TASK_5MS_MEASURING_Pin,0);
}
void meaure_task_pinClr_10ms(void)
{
    HAL_GPIO_WritePin(TASK_10MS_MEASURING_GPIO_Port,TASK_10MS_MEASURING_Pin,0);
}
void meaure_task_pinClr_100ms(void)
{
    HAL_GPIO_WritePin(TASK_100MS_MEASURING_GPIO_Port,TASK_100MS_MEASURING_Pin,0);
}
void meaure_task_pinClr_500ms(void)
{
    HAL_GPIO_WritePin(TASK_500MS_MEASURING_GPIO_Port,TASK_500MS_MEASURING_Pin,0);
}

/*---- UART ----*/
