#pragma once

#include "main.h"
#include <stdbool.h>

extern ADC_HandleTypeDef hadc1;
extern UART_HandleTypeDef huart2;

#define POMETER_HANDLER     &hadc1
#define UART_HANDLER        &huart2

/*10ms*/
void dummy_calculation(void); 
/*500ms*/
void boardLED_toggleStat(void);
void boardLED_setOn(void);
void poMeter_updateVoltage(void);
float poMeter_getVoltage(void);
/*UART*/
void uart_HeartBeat_sig(uint16_t overRunCnt);
void uart_send_staticStr(const char* str);
void uart_send_hookStr(const char* str);
/*measure*/
void meaure_task_pinSet_1ms(void);
void meaure_task_pinSet_5ms(void);
void meaure_task_pinSet_10ms(void);
void meaure_task_pinSet_100ms(void);
void meaure_task_pinSet_500ms(void);
void meaure_task_pinClr_1ms(void);
void meaure_task_pinClr_5ms(void);
void meaure_task_pinClr_10ms(void);
void meaure_task_pinClr_100ms(void);
void meaure_task_pinClr_500ms(void);
