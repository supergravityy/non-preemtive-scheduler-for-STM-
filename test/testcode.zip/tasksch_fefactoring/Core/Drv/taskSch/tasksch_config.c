/*--------------------------------------*/
// Author   : sungsoo
// Date     : 25.09.20
// Target   : STM32F103C8
/*--------------------------------------*/

/*===== tasksch_config.c =====*/

#include "main.h"
#include "tasksch_config.h"
#include <stdbool.h>

#include "../Drv/taskSch/tasksch.h"
#include "../Drv/fnd/fnd_ctrl.h"
#include "../Drv/tempSens/OW.h"
#include "../Drv/tempSens/TempSensor.h"
#include "../Drv/others/others.h"

#define VALIDATE_TASK_INFO(taskPtr, taskPeriod) ((taskPtr == NULL) || (taskPeriod == 0U))

#if (TASKSCH_TASK_WATCHDOG == TASKSCH_WATCHDOG_ENABLE)
#ifdef TASKSCH_STM32_HAL_USE

static IWDG_HandleTypeDef hiwdg; // IWDG handle in STM32 HAL

#endif
#endif

static typUserRegiTaskObj vUserRegiTaskObj[TASKSCH_NUMBER];

/* Define your Task */

void tasksch_userTask_1ms(void)
{
    // User-defined task to be executed every 1 ms
    meaure_task_pinSet_1ms();

    fnd_printNumber_1ms();

    meaure_task_pinClr_1ms();
}
void tasksch_userTask_5ms(void)
{
    // User-defined task to be executed every 5 ms
    meaure_task_pinSet_5ms();

    oneWire_5ms();

    meaure_task_pinClr_5ms();
}
void tasksch_userTask_10ms(void)
{
    // User-defined task to be executed every 10 ms
    meaure_task_pinSet_10ms();

    dummy_calculation();

    meaure_task_pinClr_10ms();
}
void tasksch_userTask_100ms(void)
{
    // User-defined task to be executed every 100 ms
    meaure_task_pinSet_100ms();

    tempSensor_100ms();
    fnd_setFloat(tempSensor_getTemper_celcius(), CENTI_RESOL);

    meaure_task_pinClr_100ms();
}
bool dummy_reqFailed;
void tasksch_userTask_500ms(void)
{
    // User-defined task to be executed every 500 ms
    meaure_task_pinSet_500ms();

    poMeter_updateVoltage();
    boardLED_toggleStat();
    tempSensor_reqCommand(TEMPSENS_CMD_REQ_DATA, NULL, &dummy_reqFailed);

    meaure_task_pinClr_500ms();
}
extern uint16_t tasksch_getOverRunCount();
void tasksch_userTask_1000ms(void)
{
	//uart_HeartBeat_sig(tasksch_getOverRunCount());
    // User-defined task to be executed every 1000 ms
}

void tasksch_init_RegiTaskObj(void)
{
    /* hard-coded Registor task initialization */

    // Example:
    // vUserRegiTaskObj[0].regiTaskFunc_ptr = UserTask1;  // User-defined function
    // vUserRegiTaskObj[0].regiTaskPeriod_ms = 1000;  // 1 second
    // vUserRegiTaskObj[0].regiTaskOffset_ms = 0;  // No offset delay

    vUserRegiTaskObj[0].regiTaskFunc_ptr = tasksch_userTask_1ms;
    vUserRegiTaskObj[0].regiTaskPeriod_ms = 1;
    vUserRegiTaskObj[0].regiTaskOffset_ms = 0;

    vUserRegiTaskObj[1].regiTaskFunc_ptr = tasksch_userTask_5ms;
    vUserRegiTaskObj[1].regiTaskPeriod_ms = 5;
    vUserRegiTaskObj[1].regiTaskOffset_ms = 0;

    vUserRegiTaskObj[2].regiTaskFunc_ptr = tasksch_userTask_10ms;
    vUserRegiTaskObj[2].regiTaskPeriod_ms = 10;
    vUserRegiTaskObj[2].regiTaskOffset_ms = 0;

    vUserRegiTaskObj[3].regiTaskFunc_ptr = tasksch_userTask_100ms;
    vUserRegiTaskObj[3].regiTaskPeriod_ms = 100;
    vUserRegiTaskObj[3].regiTaskOffset_ms = 0;

    vUserRegiTaskObj[4].regiTaskFunc_ptr = tasksch_userTask_500ms;
    vUserRegiTaskObj[4].regiTaskPeriod_ms = 500;
    vUserRegiTaskObj[4].regiTaskOffset_ms = 0;

    vUserRegiTaskObj[5].regiTaskFunc_ptr = tasksch_userTask_1000ms;
    vUserRegiTaskObj[5].regiTaskPeriod_ms = 1000;
    vUserRegiTaskObj[5].regiTaskOffset_ms = 1000;
}

/* Define your Exit Hook Function */

extern typExecTimer tasksch_getCurrTime(void);
extern struct typExecTimer;
uint8_t thsld = 30;

bool tasksch_requestExit(void)
{
	typExecTimer clk = tasksch_getCurrTime();

	if(clk.min >= thsld)
		return true ;
	else
		return false;

    // User can override this function in tasksch_config.c
    return false;
}

void tasksch_user_preExit_schedulerHook(void)
{
	uart_send_beforeOFF("Good Bye Host!\r\n");
    return;
}

/* Define your Major Cycle Hook Function */

uint16_t tasksch_getOverRunCount(void);

void tasksch_userMajorCycleHook(void)
{
    // If the user wants to define a major cycle Hook function, write it here.
    // ex) LED toggle, status check, UART status communication, etc.

    uart_HeartBeat_sig(tasksch_getOverRunCount());
}

void tasksch_userInitCmpltHook(void)
{
	uart_send_staticStr("Hello Host!\r\n");
}

/* Define your Overrun Threshold Exceed Hook Function */

void tasksch_userOverRun_thrshldExceedHook(void)
{
	uart_send_beforeOFF("TOO MANY OR! RST SCH!\r\n");
    return;
}

/* Define your Watchdog Functions */

bool tasksch_initWatchdog(void)
{
    // User can override this function in tasksch_config.c
    bool result = false;

#if (TASKSCH_TASK_WATCHDOG == TASKSCH_WATCHDOG_ENABLE) // just example how to write

#ifdef TASKSCH_STM32_HAL_USE
    result = true;
    // nothing to do in init function for stm32 hal iwdg

    /*if (user_custom_iwdg_init(my_wdg) != false)
    {
        // Init Error

        TASKSCH_ASSERT_FUNC();
    }*/

#endif
#else
    result = true;
#endif
    return result;
}

bool tasksch_beginWatchdog(void)
{
    // User can override this function in tasksch_config.c
    bool result = false;

#if (TASKSCH_TASK_WATCHDOG == TASKSCH_WATCHDOG_ENABLE) // just example how to write

#ifdef TASKSCH_STM32_HAL_USE
    // Start the watchdog -> Initialize the IWDG peripheral (in HAL)

    hiwdg.Instance = IWDG;
    hiwdg.Init.Prescaler = TASKSCH_WATCHDOG_PRSCLAER_BITS;
    hiwdg.Init.Reload = TASKSCH_WATCHDOG_TIMEOUT_CNT; // 375 * 8ms = 3s

    result = (HAL_IWDG_Init(&hiwdg) != HAL_OK) ? false : true;
#endif

#else
    result = true;
#endif
    return result;
}

bool tasksch_feedWatchdog(void)
{
    // User can override this function in tasksch_config.c
    bool result = false;

#if (TASKSCH_TASK_WATCHDOG == TASKSCH_WATCHDOG_ENABLE) // just example how to write
    #ifdef TASKSCH_STM32_HAL_USE
    // refresh the watchdog
    result = (HAL_IWDG_Refresh(&hiwdg) != HAL_OK) ? false : true;
    //result = false;

    #endif
#else
    result = true;
#endif
    return result;
}

void tasksch_userFeedFail_watchdogHook(void) 
{ 
    uart_send_staticStr("\r\nfeeding fail!\r\n");
    return;
}
/* User Registrated Task Object Initialization */
// INFO : Do not modify it below!!

bool tasksch_ValidateUser_RegiTaskInfos(void)
{
    bool result = true;
    for (uint8_t idx = 0; idx < TASKSCH_NUMBER; idx++)
    {
        if (VALIDATE_TASK_INFO(vUserRegiTaskObj[idx].regiTaskFunc_ptr, vUserRegiTaskObj[idx].regiTaskPeriod_ms) == true)
        {
            result = false;
            break;
        }
    }

    return result;
}

void tasksch_getUserRegi_taskInfo(uint8_t taskIdx, typUserRegiTaskObj *taskInfo)
{
    taskInfo->regiTaskFunc_ptr = vUserRegiTaskObj[taskIdx].regiTaskFunc_ptr;
    taskInfo->regiTaskPeriod_ms = vUserRegiTaskObj[taskIdx].regiTaskPeriod_ms;
    taskInfo->regiTaskOffset_ms = vUserRegiTaskObj[taskIdx].regiTaskOffset_ms;
}
